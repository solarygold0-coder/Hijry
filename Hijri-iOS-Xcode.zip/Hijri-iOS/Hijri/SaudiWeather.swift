import SwiftUI
import CoreLocation
import WeatherKit

struct SaudiWeather: View {
    private struct City: Identifiable {
        let id: String
        let title: String
        let latitude: Double
        let longitude: Double
    }
    private static let cities = [
        City(id: "riyadh", title: "الرياض", latitude: 24.7136, longitude: 46.6753),
        City(id: "jeddah", title: "جدة", latitude: 21.4858, longitude: 39.1925),
        City(id: "abha", title: "أبها", latitude: 18.2164, longitude: 42.5053),
        City(id: "dammam", title: "الدمام", latitude: 26.4207, longitude: 50.0888),
        City(id: "medina", title: "المدينة المنورة", latitude: 24.5247, longitude: 39.5692),
        City(id: "mecca", title: "مكة المكرمة", latitude: 21.3891, longitude: 39.8579)
    ]
    @AppStorage("weatherCity") private var cityID = "riyadh"
    @Environment(\.colorScheme) private var colorScheme
    @State private var forecast: [DayWeather] = []
    @State private var attribution: WeatherAttribution?
    @State private var failed = false
    @State private var attempt = 0

    private func degrees(_ value: Measurement<UnitTemperature>) -> String {
        let c = value.converted(to: .celsius)
        return "\(Int(c.value.rounded()))°"
    }
    var body: some View {
        NavigationStack {
            Form {
                Picker("المدينة", selection: $cityID) {
                    ForEach(Self.cities) { Text($0.title).tag($0.id) }
                }
                if failed {
                    Text("تعذّر تحديث الطقس.")
                    Button("إعادة المحاولة") { attempt += 1 }
                } else if forecast.isEmpty {
                    ProgressView("جارٍ تحديث الطقس…")
                } else {
                    ForEach(Array(forecast.enumerated()), id: \.offset) { index, day in
                        VStack(alignment: .leading, spacing: 8) {
                            Label(index == 0 ? "اليوم" : "غدًا", systemImage: day.symbolName).font(.headline)
                            Text("الصغرى \(degrees(day.lowTemperature)) · الكبرى \(degrees(day.highTemperature))")
                            Text(day.condition.description).foregroundStyle(.secondary)
                        }
                    }
                }
                if let attribution {
                    Link(destination: attribution.legalPageURL) {
                        AsyncImage(url: colorScheme == .dark ? attribution.combinedMarkLightURL : attribution.combinedMarkDarkURL) { image in
                            image.resizable().scaledToFit()
                        } placeholder: {
                            Text("Apple Weather")
                        }
                        .frame(maxWidth: 150, minHeight: 24, maxHeight: 36)
                    }
                }
            }
            .navigationTitle("الطقس")
            .task(id: "\(cityID)-\(attempt)") {
                guard let city = Self.cities.first(where: { $0.id == cityID }) else { return }
                forecast = []; attribution = nil; failed = false
                do {
                    let service = WeatherService.shared
                    let location = CLLocation(latitude: city.latitude, longitude: city.longitude)
                    let weather = try await service.weather(for: location)
                    let credit = try await service.attribution
                    guard !Task.isCancelled else { return }
                    forecast = Array(weather.dailyForecast.forecast.prefix(2))
                    attribution = credit
                    failed = forecast.isEmpty
                } catch {
                    if !Task.isCancelled { failed = true }
                }
            }
        }
    }
}
