import Foundation
import SwiftUI
import UserNotifications
#if canImport(AlarmKit)
import AlarmKit
#endif

enum ReminderRepeat: String, Codable, CaseIterable, Identifiable {
    case once, daily, weekly
    var id: Self { self }
    var title: String {
        switch self {
        case .once: return "مرة واحدة"
        case .daily: return "يوميًا"
        case .weekly: return "أسبوعيًا"
        }
    }
}
struct HijriReminder: Identifiable, Codable {
    var id = UUID()
    let title: String
    let date: Date
    let usesSystemAlarm: Bool
    var recurrence: ReminderRepeat? = nil
    var repeatMode: ReminderRepeat { recurrence ?? .once }
}

@MainActor
final class Reminders: ObservableObject {
    @Published private(set) var entries: [HijriReminder] = []
    @Published var error: String?
    private let key = "hijri.reminders"
    private let center = UNUserNotificationCenter.current()

    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode([HijriReminder].self, from: data) {
            entries = saved
        }
    }

    private func save() {
        if let data = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    func add(title: String, date selectedDate: Date, recurrence: ReminderRepeat) async -> Bool {
        let date = Calendar.current.dateInterval(of: .minute, for: selectedDate)?.start ?? selectedDate
        let name = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, recurrence != .once || date > Date() else {
            error = "أدخل اسم الموعد واختر وقتًا في المستقبل."
            return false
        }
        do {
            #if canImport(AlarmKit)
            if #available(iOS 26.0, *) {
                let item = HijriReminder(title: name, date: date, usesSystemAlarm: true, recurrence: recurrence)
                let manager = AlarmManager.shared
                guard try await manager.requestAuthorization() == .authorized else {
                    error = "اسمح لتطبيق هجري بجدولة المنبّهات من الإعدادات."
                    return false
                }
                guard recurrence != .once || date > Date() else {
                    error = "انقضى الوقت المحدد. اختر وقتًا آخر."
                    return false
                }
                let stop = AlarmButton(text: "إيقاف", textColor: .white, systemImageName: "stop.circle")
                let alert = AlarmPresentation.Alert(title: LocalizedStringResource(stringLiteral: name), stopButton: stop)
                let attributes = AlarmAttributes(presentation: AlarmPresentation(alert: alert),
                                                 metadata: HijriAlarmMetadata(), tintColor: Color.teal)
                let schedule: Alarm.Schedule
                if recurrence == .once {
                    schedule = .fixed(date)
                } else {
                    let cal = Calendar.current
                    let weekday = cal.component(.weekday, from: date)
                    let weekdays: [Locale.Weekday] = [.sunday, .monday, .tuesday, .wednesday, .thursday, .friday, .saturday]
                    schedule = .relative(.init(time: .init(hour: cal.component(.hour, from: date),
                                                         minute: cal.component(.minute, from: date)),
                                               repeats: .weekly(recurrence == .daily ? weekdays : [weekdays[weekday - 1]])))
                }
                let configuration = AlarmManager.AlarmConfiguration<HijriAlarmMetadata>.alarm(
                    schedule: schedule, attributes: attributes,
                    stopIntent: nil, secondaryIntent: nil, sound: .default)
                _ = try await manager.schedule(id: item.id, configuration: configuration)
                entries.append(item)
                save()
                return true
            }
            #endif
            guard try await center.requestAuthorization(options: [.alert, .sound]) else {
                error = "اسمح بإشعارات هجري من الإعدادات."
                return false
            }
            let interval = date.timeIntervalSinceNow
            guard recurrence != .once || interval >= 1 else {
                error = "انقضى الوقت المحدد. اختر وقتًا آخر."
                return false
            }
            let item = HijriReminder(title: name, date: date, usesSystemAlarm: false, recurrence: recurrence)
            let content = UNMutableNotificationContent()
            content.title = name
            content.body = "حان وقت موعدك."
            content.sound = .default
            let trigger: UNNotificationTrigger
            if recurrence == .once {
                trigger = UNTimeIntervalNotificationTrigger(timeInterval: interval, repeats: false)
            } else {
                let fields: Set<Calendar.Component> = recurrence == .daily ? [.hour, .minute] : [.weekday, .hour, .minute]
                trigger = UNCalendarNotificationTrigger(dateMatching: Calendar.current.dateComponents(fields, from: date), repeats: true)
            }
            try await center.add(UNNotificationRequest(identifier: item.id.uuidString, content: content, trigger: trigger))
            entries.append(item)
            save()
            return true
        } catch {
            self.error = "تعذّرت جدولة الموعد. تحقّق من الأذونات والوقت المختار."
            return false
        }
    }

    @discardableResult
    func remove(_ item: HijriReminder) -> Bool {
        #if canImport(AlarmKit)
        if #available(iOS 26.0, *), item.usesSystemAlarm {
            let manager = AlarmManager.shared
            do {
                if try manager.alarms.contains(where: { $0.id == item.id }) {
                    try manager.cancel(id: item.id)
                }
            } catch {
                self.error = "تعذّر إلغاء المنبّه. حاول مرة أخرى."
                return false
            }
        }
        #endif
        center.removePendingNotificationRequests(withIdentifiers: [item.id.uuidString])
        center.removeDeliveredNotifications(withIdentifiers: [item.id.uuidString])
        entries.removeAll { $0.id == item.id }
        save()
        return true
    }
}

#if canImport(AlarmKit)
@available(iOS 26.0, *)
private struct HijriAlarmMetadata: AlarmMetadata {}
#endif
