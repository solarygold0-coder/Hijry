import SwiftUI
import UIKit
import UserNotifications

final class NotificationDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        return true
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification) async -> UNNotificationPresentationOptions {
        [.banner, .sound]
    }
}

@main
@MainActor
struct HijriApp: App {
    @UIApplicationDelegateAdaptor(NotificationDelegate.self) private var notifications
    @StateObject private var reminders = Reminders()
    private let table = UmmAlQura.bundled

    var body: some Scene {
        WindowGroup {
            TabView {
                if let table {
                    CalendarScreen(table: table)
                        .tabItem { Label("التقويم", systemImage: "calendar") }
                } else {
                    Text("تعذّر تحميل جدول أم القرى.")
                        .tabItem { Label("التقويم", systemImage: "calendar") }
                }
                OccasionsScreen(table: table)
                    .tabItem { Label("المناسبات", systemImage: "calendar.badge.clock") }
                SaudiWeather()
                    .tabItem { Label("الطقس", systemImage: "cloud.sun") }
                ReminderScreen(reminders: reminders)
                    .tabItem { Label("المواعيد", systemImage: "alarm") }
            }
            .tint(.teal)
            .environment(\.locale, Locale(identifier: "ar_SA"))
            .environment(\.layoutDirection, .rightToLeft)
        }
    }
}

private struct CalendarScreen: View {
    let table: UmmAlQura
    @State private var selected = Date()
    @State private var editHijri = false

    var body: some View {
        NavigationStack {
            Form {
                Section("تاريخ أم القرى") {
                    if let hijri = table.convert(selected) {
                        LabeledContent("الهجري", value: "\(hijri.day) \(UmmAlQura.months[hijri.month - 1]) \(hijri.year)")
                    }
                    LabeledContent("اليوم") { Text(selected, format: .dateTime.weekday(.wide)) }
                    Button("اختيار تاريخ هجري") { editHijri = true }
                }
                Section("التاريخ الميلادي") {
                    DatePicker("التاريخ", selection: $selected, in: table.range, displayedComponents: .date)
                        .environment(\.calendar, Calendar(identifier: .gregorian))
                    Button("تاريخ اليوم") { selected = Date() }
                }
            }
            .navigationTitle("هجري")
            .sheet(isPresented: $editHijri) {
                HijriPicker(table: table, current: selected) { selected = $0 }
            }
        }
    }
}

private struct HijriPicker: View {
    let table: UmmAlQura
    let choose: (Date) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var year: Int
    @State private var month: Int
    @State private var day: Int

    init(table: UmmAlQura, current: Date, choose: @escaping (Date) -> Void) {
        self.table = table
        self.choose = choose
        let start = table.convert(current) ?? CivilDay(year: 1448, month: 1, day: 1)
        _year = State(initialValue: start.year)
        _month = State(initialValue: start.month)
        _day = State(initialValue: start.day)
    }
    private var count: Int { table.monthLength(year: year, month: month) }

    var body: some View {
        NavigationStack {
            Form {
                Picker("السنة", selection: $year) {
                    ForEach(1300...1600, id: \.self) { Text(String($0)).tag($0) }
                }
                Picker("الشهر", selection: $month) {
                    ForEach(1...12, id: \.self) { Text(UmmAlQura.months[$0 - 1]).tag($0) }
                }
                Picker("اليوم", selection: $day) {
                    ForEach(1...count, id: \.self) { Text(String($0)).tag($0) }
                }
            }
            .onChange(of: count) { day = min(day, $0) }
            .navigationTitle("التاريخ الهجري")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("إلغاء") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("تم") {
                        if let date = table.date(year: year, month: month, day: min(day, count)) {
                            choose(date)
                            dismiss()
                        }
                    }
                }
            }
        }
    }
}

private struct ReminderScreen: View {
    @ObservedObject var reminders: Reminders
    @State private var title = ""
    @State private var date = Date().addingTimeInterval(3600)
    @State private var busy = false
    @State private var recurrence: ReminderRepeat = .once
    @State private var toDelete: HijriReminder?

    var body: some View {
        NavigationStack {
            Form {
                Section("إضافة موعد") {
                    TextField("اسم الموعد", text: $title)
                    DatePicker("الوقت", selection: $date, displayedComponents: [.date, .hourAndMinute])
                        .environment(\.calendar, Calendar(identifier: .gregorian))
                    Picker("التكرار", selection: $recurrence) {
                        ForEach(ReminderRepeat.allCases) { Text($0.title).tag($0) }
                    }
                    if recurrence != .once { Text("يبدأ التكرار عند أقرب وقت مطابق.").font(.footnote).foregroundStyle(.secondary) }
                    Button(busy ? "جارٍ الحفظ…" : "حفظ الموعد") {
                        busy = true
                        Task {
                            if await reminders.add(title: title, date: date, recurrence: recurrence) { title = "" }
                            busy = false
                        }
                    }
                    .disabled(busy || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    if #unavailable(iOS 26.0) {
                        Text("يصل الموعد كإشعار محلي على هذا الإصدار من iOS.").font(.footnote).foregroundStyle(.secondary)
                    }
                }
                Section("المواعيد المحفوظة") {
                    if reminders.entries.isEmpty {
                        Text("لا توجد مواعيد.").foregroundStyle(.secondary)
                    }
                    ForEach(reminders.entries.sorted { $0.date < $1.date }) { item in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.title).font(.headline)
                            Text(item.repeatMode == .once ? item.date.formatted(date: .abbreviated, time: .shortened) : item.date.formatted(date: .omitted, time: .shortened) + " · " + item.repeatMode.title).foregroundStyle(.secondary)
                        }
                        .swipeActions(allowsFullSwipe: false) {
                            Button("حذف", role: .destructive) { toDelete = item }
                        }
                    }
                }
            }
            .navigationTitle("المواعيد")
            .confirmationDialog("حذف الموعد؟", isPresented: Binding(
                get: { toDelete != nil }, set: { if !$0 { toDelete = nil } }),
                titleVisibility: .visible, presenting: toDelete) { item in
                    Button("حذف «\(item.title)»", role: .destructive) { reminders.remove(item); toDelete = nil }
                    Button("إلغاء", role: .cancel) { toDelete = nil }
                }
            .alert("المواعيد", isPresented: Binding(
                get: { reminders.error != nil }, set: { if !$0 { reminders.error = nil } })) {
                    Button("حسنًا") { reminders.error = nil }
                } message: { Text(reminders.error ?? "") }
        }
    }
}
